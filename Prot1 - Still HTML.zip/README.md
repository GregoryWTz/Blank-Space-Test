README:
GROUP NAMES:
- Daniel Kurnia G
- Nicholas Dharma Tan
- Gregorius William Tanuwijaya

Rules:
- space exploration game
- planets are food themed and each letter corresponds to a planet
- each planet has its own purpose
planet a = apple, fight against the worm. Everything you do here is a fight and you will get money
planet b = butter, try to swim in the butter, it gives you hygine
planet c = cookie, with a big planet, you can almost do anything
planet d = donut, a planet that was made pure from dough, can recover your hunger
planet e = espresso, caffein.. gives energy
- every actions in every planet to make your bar higher takes currency and if your curreny is 0, you can not fill your status
- at the apple planet, you can earn money, BUT you have to sacrefice one of your status bars
- each planets also has its own actions that can decrease your status bar
- player dies when any stat reaches 0